from Sprites import *
import pygame as pg
from os import path
import heapq
vec = pg.math.Vector2

class PriorityQueue:
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        return len(self.nodes) == 0

def draw_grid():
    for x in range(0, WIDTH, TILESIZE):
        pg.draw.line(screen, DARKGRAY, (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT, TILESIZE):
        pg.draw.line(screen, DARKGRAY, (0, y), (WIDTH, y))

def draw_icons():
    start_center = (goal.x * TILESIZE + TILESIZE / 2, goal.y * TILESIZE + TILESIZE / 2)
    screen.blit(Client_img, Client_img.get_rect(center=start_center))
    goal_center = (start.x * TILESIZE + TILESIZE / 2, start.y * TILESIZE + TILESIZE / 2)
    screen.blit(Cab_img, Cab_img.get_rect(center=goal_center))

def vec2int(v):
    return (int(v.x), int(v.y))

def heuristic(a, b):
    # return abs(a.x - b.x) ** 2 + abs(a.y - b.y) ** 2
    return (abs(a.x - b.x) + abs(a.y - b.y)) * 10

def a_star_search(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(vec2int(start), 0)
    path = {}
    cost = {}
    path[vec2int(start)] = None
    cost[vec2int(start)] = 0

    while not frontier.empty():
        current = frontier.get()
        if current == end:
            break
        for next in graph.find_neighbors(vec(current)):
            next = vec2int(next)
            next_cost = cost[current] + graph.cost(current, next)
            if next not in cost or next_cost < cost[next]:
                cost[next] = next_cost
                priority = next_cost + heuristic(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    return path, cost

def dijkstra_search(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(vec2int(start), 0)
    path = {}
    cost = {}
    path[vec2int(start)] = None
    cost[vec2int(start)] = 0

    while not frontier.empty():
        current = frontier.get()
        if current == end:
            break
        for next in graph.find_neighbors(vec(current)):
            next = vec2int(next)
            next_cost = cost[current] + graph.cost(current, next)
            if next not in cost or next_cost < cost[next]:
                cost[next] = next_cost
                priority = next_cost
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    return path, cost

#importing images to use tu represent the goal, start and the best path
icon_dir = path.join(path.dirname(__file__), 'C:/Users/Baone Baitsile/PycharmProjects/AssignmentFinal/icons')
Client_img = pg.image.load(path.join(icon_dir, 'Client.png')).convert_alpha()
Client_img = pg.transform.scale(Client_img, (50, 50))
Client_img.fill((0, 255, 0, 255), special_flags=pg.BLEND_RGBA_MULT)
Cab_img = pg.image.load(path.join(icon_dir, 'Cab.png')).convert_alpha()
Cab_img = pg.transform.scale(Cab_img, (50, 50))
Cab_img.fill((255, 0, 0, 255), special_flags=pg.BLEND_RGBA_MULT)
arrows = {}
arrow_img = pg.image.load(path.join(icon_dir, 'arrowRight.png')).convert_alpha()
arrow_img = pg.transform.scale(arrow_img, (50, 50))
for dir in [(1, 0), (0, 1), (-1, 0), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]:
    arrows[dir] = pg.transform.rotate(arrow_img, vec(dir).angle_to(vec(1, 0)))

#the section below sets the grid where the program is layed.
g = WeightedGrid(GRIDWIDTH, GRIDHEIGHT)
walls = [(0, 2), (1, 2), (0, 1), (0, 0), (4, 0), (4, 1), (4, 2), (3, 2), (6, 0), (6, 1), (6, 2), (7, 2),
         (9, 2), (10, 2), (10, 1), (10, 0), (12, 0), (12, 1), (12, 2), (13, 2), (15, 2), (16, 2), (16, 1),
         (16, 0), (18, 0), (18, 1), (18, 2), (19, 2), (21, 2), (22, 2), (22, 1), (22, 0), (24, 0), (24, 1),
         (24, 2), (25, 2), (27, 2), (27, 1), (27, 0), (0, 12), (0, 13), (0, 14), (1, 12), (3, 12), (4, 12),
         (4, 13), (4, 14), (6, 12), (6, 13), (6, 14), (7, 12), (9, 12), (10, 12), (10, 13), (10, 14), (12, 12),
         (12, 13), (12, 14), (13, 12), (15, 12), (16, 12), (16, 13), (16, 14), (18, 12), (18, 13), (18, 14),
         (19, 12), (21, 12), (22, 12), (22, 13), (22, 14), (24, 12), (24, 13), (24, 14), (25, 12), (27, 12),
         (27, 13), (27, 14), (0, 9), (1, 9), (4, 9), (5, 9), (7, 9), (8, 9), (15, 9), (16, 9), (17, 9), (19, 9),
         (20, 9), (21, 9), (23, 9), (24, 9), (25, 9), (27, 9), (2, 7), (2, 9), (0, 5), (1, 5), (2, 5), (1, 7), (5, 5),
         (4, 5), (4, 7), (5, 7), (8, 5), (7, 5), (8, 7), (7, 7), (11, 5), (12, 5), (11, 9), (12, 9), (11, 7), (12, 7),
         (15, 5), (16, 5), (15, 7), (16, 7), (13, 5), (13, 7), (13, 9), (9, 9), (9, 7), (9, 5), (0, 7), (17, 5), (17, 7),
         (19, 5), (20, 5), (21, 5), (19, 7), (20, 7), (21, 7), (25, 5), (24, 5), (23, 5), (27, 5), (23, 7), (24, 7),
         (25, 7), (27, 7), (14, 14), (8, 14), (2, 14), (20, 14), (26, 14), (26, 0), (20, 0), (14, 0), (8, 0), (2, 0)]

#this section deals with the construction of walls on the grid
for wall in walls:
    g.walls.append(vec(wall))
terrain = [(11, 6), (12, 6), (13, 6), (14, 6), (15, 6), (10, 7), (11, 7), (12, 7), (13, 7),
           (14, 7), (15, 7), (16, 7), (16, 8), (15, 8), (14, 8), (13, 8), (12, 8), (11, 8),
           (10, 8), (11, 9), (12, 9), (13, 9), (14, 9), (15, 9), (11, 10), (12, 10), (13, 10),
           (14, 10), (15, 10), (12, 11), (13, 11), (14, 11), (12, 5), (13, 5), (14, 5), (11, 5),
           (15, 5), (12, 4), (13, 4), (14, 4)]
terrain = []
for tile in terrain:
    g.weights[tile] = 15

goal = vec(14, 8)   # sets the tile where the end node is originally placed
start = vec(21, 0) # sets the tile where the start node is initially placed
search_type = a_star_search #sets the search type in use.
path, c = search_type(g, goal, start)

#configures the keyboard key responses
running = True
while running:
    clock.tick(FPS)
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                running = False
            if event.key == pg.K_SPACE:
                if search_type == a_star_search:
                    search_type = dijkstra_search
                else:
                    search_type = a_star_search
                path, c = search_type(g, goal, start)

            # Pressing the M key prints a list of the wall vectors
            if event.key == pg.K_m:
                print([(int(loc.x), int(loc.y)) for loc in g.walls])

#this section helps in changing the positions of the start & goal nodes
        if event.type == pg.MOUSEBUTTONDOWN:
            mpos = vec(pg.mouse.get_pos()) // TILESIZE
            if event.button == 1:
                if mpos in g.walls:
                    g.walls.remove(mpos)
                else:
                    g.walls.append(mpos)
            if event.button == 2:
                start = mpos
            if event.button == 3:
                goal = mpos
            path, c = search_type(g, goal, start)

#prints the number of frames used from the start node to goal node
    pg.display.set_caption("{:.2f}".format(clock.get_fps()))
    screen.fill(WHITE)

    # fill explored area
    for node in path:
        x, y = node
        rect = pg.Rect(x * TILESIZE, y * TILESIZE, TILESIZE, TILESIZE)
        pg.draw.rect(screen, MEDGRAY, rect)
    draw_grid()
    g.draw()

    # draw path from start to goal
    current = start # + path[vec2int(start)]
    l = 0
    while current != goal:
        v = path[(current.x, current.y)]
        if v.length_squared() == 1:
            l += 10
        else:
            l += 14
        img = arrows[vec2int(v)]
        x = current.x * TILESIZE + TILESIZE / 2
        y = current.y * TILESIZE + TILESIZE / 2
        r = img.get_rect(center=(x, y))
        screen.blit(img, r)

        # find next in path
        current = current + path[vec2int(current)]
    draw_icons()
    draw_text(search_type.__name__, 30, MAGENTA, WIDTH - 10, HEIGHT - 10, align="bottomright")
    draw_text('Distance to Client:{}'.format(l), 30, RED, WIDTH - 10, HEIGHT - 45, align="bottomright")
    pg.display.flip()
